const Stream = require("./camera-stream");
stream = new Stream({
    name: "",
    url: "",
    port: 5000,
});
